import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

// Render the root application
ReactDOM.render(<App />, document.getElementById("root"));
