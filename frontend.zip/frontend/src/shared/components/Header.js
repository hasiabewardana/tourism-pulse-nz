import React from "react";

// Header component for shared navigation
const Header = () => {
  return (
    <div style={{ padding: "10px", backgroundColor: "#f5f5f5" }}>
      <h3>TourismPulseNZ</h3>
    </div>
  );
};

export default Header;
